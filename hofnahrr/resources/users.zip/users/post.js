this.registeredAt = (new Date()).getTime();
this.lastVisitAt = (new Date()).getTime();
this.isAdmin = this.isAdmin || false;
this.network = this.network || 'internal';
